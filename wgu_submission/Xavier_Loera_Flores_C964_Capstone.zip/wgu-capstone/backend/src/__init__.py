from Controllers import posts_controller
import main
from Controllers import model
import Routers