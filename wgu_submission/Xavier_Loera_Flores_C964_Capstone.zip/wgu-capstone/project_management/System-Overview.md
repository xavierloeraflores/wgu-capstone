# System Overview

Links to the different parts of the system.

- [Frontend Deployment](https://wgu-capstone-xavier-loera-flores.vercel.app/)
- [Backend Deployment](https://wgu-capstone-production.up.railway.app)
- [API Docs](https://wgu-capstone-docs.vercel.app)
- [GitHub Repository](https://github.com/xavierloeraflores/wgu-capstone)
