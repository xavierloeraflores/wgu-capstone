# References 

- Hotz, Nick "What is CRISP DM?" Data Science Process Alliance https://www.datascience-pm.com/crisp-dm-2/ Accessed Feb 20,2024.

- Toosi, Ali "Twitter Sentinment Analysis" Kaggle https://www.kaggle.com/datasets/arkhoshghalb/twitter-sentiment-analysis-hatred-speech Accessed Feb 20,2024.

- Samoshyn, Andrii "Hate Speech & Offensive Language" Kaggle https://www.kaggle.com/datasets/mrmorj/hate-speech-and-offensive-language-dataset/data Accessed Feb 20,2024.